/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mahasiswa;

/**
 *
 * @author ACER
 */
public class Main {
    public static void main(String[] args){
        Mahasiswa joni = new Mahasiswa("Joni", 12345, 5, 3.5);
        
        System.out.println("Nama: " + joni.getNama());
        System.out.println("NIM: " + joni.getNim());
        System.out.println("Semester: " + joni.getSemester());
        System.out.println("IP: " + joni.getIp());
        System.out.println("Jumlah SKS: " + joni.getJumlahSks());
        
    }
}
