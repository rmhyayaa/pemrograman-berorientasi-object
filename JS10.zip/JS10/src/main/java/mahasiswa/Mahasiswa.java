/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mahasiswa;

/**
 *
 * @author ACER
 */
public class Mahasiswa {
    private String nama;
    private int nim;
    private int semester;
    private double ip;
    
    public Mahasiswa(String nama, int nim, int semester, double ip){
        this.nama = nama;
        this.nim = nim;
        this.semester = semester;
        this.ip = ip;
    }
    public String getNama(){
        return nama;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public int getNim(){
        return nim;
    }
    public void setNim(int nim){
        this.nim = nim;
    }
    public int getSemester(){
        return semester;
    }
    public void setSemester(int semester){
        this.semester = semester;
    }
    public double getIp(){
        return ip;
    }
    public void setIp(double ip){
        this.ip = ip;
    }
    public int getJumlahSks(){
        int jumlahSks = 0;
        if (ip>=3.5){
            jumlahSks = 24;
        } else if (ip>=3.0){
            jumlahSks = 22;
        } else if (ip>=2.5){
            jumlahSks = 20;
        } else if (ip>=2.0){
            jumlahSks = 18;
        } else {
            jumlahSks = 15;
        }
        return jumlahSks;
    }
}

