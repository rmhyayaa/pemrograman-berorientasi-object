/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartphone;

/**
 *
 * @author ACER
 */
public class AndroMain {
    public static void main(String[] args){
        Android android = new Android();
        
        //panggil method nyala
        android.nyala();
        
        //panggil method panggilan
        android.panggilan();
        
        //panggil method sms
        android.sms();
        
        //panggil method shutdown
        android.shutdown();
    }
}
