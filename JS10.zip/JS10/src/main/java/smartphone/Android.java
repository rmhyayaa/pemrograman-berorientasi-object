/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartphone;

/**
 *
 * @author ACER
 */
public class Android {
    public void nyala(){
        System.out.println("Android menyala");
    }
    public void panggilan(){
        System.out.println("Kring Kring Kring, ada panggilan masuk");
    }
    public void sms(){
        System.out.println("Tenenoeeett, ada SMS baru");
    }
    public void shutdown(){
        System.out.println("Android dimatikan");
    }
}
