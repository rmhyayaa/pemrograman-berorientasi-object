/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js03;

/**
 *
 * @author ACER
 */
public class TUGAS {
    public static void main(String[] args){
        int number=10;
        char letter='a';
        boolean result=true;
        String str="hello";
        
        System.out.println("Number="+number);
        System.out.println("Letter="+letter);
        System.out.println("Result="+result);
        System.out.println("Str="+str);
    }
    
}
