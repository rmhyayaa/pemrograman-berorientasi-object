/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//created by 22343028_Ramadhani maulidia Hilma
package com.mycompany.js03;

/**
 *
 * @author ACER
 */
public class LATIHAN3 {
    public static void main (String[] args){
        int value=10;
        char x;
        x='A';
        
        System.out.println(value);
        System.out.println("The value of x="+x);
    }
}
