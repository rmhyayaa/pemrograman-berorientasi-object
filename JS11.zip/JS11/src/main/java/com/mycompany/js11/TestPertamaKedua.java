/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js11;

/**
 *
 * @author ACER
 */
public class TestPertamaKedua {
    public static void main (String[] args){
        Kedua D2 = new Kedua();
        D2.BacaSuper();
        D2.info();
        
        pertama S1 = new pertama();
        S1.terprotek();
        S1.info();
    }
}
