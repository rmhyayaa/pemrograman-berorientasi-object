/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Latihan3_Inheritance;

/**
 *
 * @author ACER
 */
public class Hewan {
    public static void testClassMethod(){
        System.out.println("The class method in Hewan");
        
    }
    
    public void testInstanceMethod(){
        System.out.println("The Instance Method in Hewan");
    }
}
