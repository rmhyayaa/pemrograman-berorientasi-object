/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Latihan2_Inheritance.newpackage;

/**
 *
 * @author ACER
 */
public class KonstruktorSuperClass {
    public static void main (String[] args){
        Employ programmer1 = new Employ ("12345678", "Budi", 33);
        programmer1.info();
    }
}
