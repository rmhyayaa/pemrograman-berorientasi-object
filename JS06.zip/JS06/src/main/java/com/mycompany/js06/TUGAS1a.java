/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js06;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author ACER
 */
public class TUGAS1a {
    public static void main(String[] args) throws IOException{
        BufferedReader input = new BufferedReader (new InputStreamReader(System.in));
        int nilai1, nilai2, nilai3;
        float rataRata;
        
        System.out.println("Masukkan nilai ujian 1: ");
        nilai1 = Integer.parseInt(input.readLine());
        System.out.println("Masukkan nilai ujian 2: ");
        nilai2 = Integer.parseInt(input.readLine());
        System.out.println("Masukkan nilai ujian 3: ");
        nilai3 = Integer.parseInt(input.readLine());
        
        rataRata = (nilai1 + nilai2 + nilai3) / 3;
        
        System.out.println("Rata-rata nilai ujian: "+ rataRata);
        if (rataRata >= 60){
            System.out.println(" :-) ");
        }
        else{
            System.out.println(" :-( ");
        }
    }
}
