/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js06;
import javax.swing.JOptionPane;
/**
 *
 * @author ACER
 */
public class Tugas1b {
    public static void main(String[] args){
        
        int nilai1, nilai2, nilai3;
        float rataRata;
        
        nilai1 = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nilai ujian 1: "));
        nilai2 = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nilai ujian 2: "));
        nilai3 = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nilai ujian 3: "));
        
        rataRata = (nilai1 + nilai2 + nilai3) / 3;
        
        JOptionPane.showMessageDialog(null, "Rata-rata nilai ujian: " + rataRata);
        if(rataRata>=60){
            JOptionPane.showMessageDialog(null, " :-) ");
        }
        else{
            JOptionPane.showMessageDialog(null, " :-( ");
        }
        
    }
}