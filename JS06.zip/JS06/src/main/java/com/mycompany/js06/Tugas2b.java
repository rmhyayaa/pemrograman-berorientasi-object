/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js06;
import java.util.Scanner;
/**
 *
 * @author ACER
 */
public class Tugas2b {
    public static void main(String[] args){
        
        int angka;
        String kata;
        
        Scanner input = new Scanner(System.in);
        System.out.println("Masukkan angka: ");
        angka = input.nextInt();
        
        switch (angka){
            case 1:
                kata = "satu";
                break;
            case 2:
                kata = "dua";
                break;
            case 3:
                kata = "tiga";
                break;
            case 4:
                kata = "empat";
                break;
            case 5:
                kata = "lima";
                break;
            case 6:
                kata = "enam";
                break;
            case 7:
                kata = "tujuh";
                break;
            case 8:
                kata = "delapan";
                break;
            case 9:
                kata = "sembilan";
                break;
            case 10:
                kata = "sepuluh";
                break;
            default:
                kata = "Invalid Number";
        }
        System.out.println("Angka" + angka + " = " + kata);
    }
}
