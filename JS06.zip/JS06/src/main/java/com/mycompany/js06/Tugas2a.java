/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js06;
import java.util.Scanner;
/**
 *
 * @author ACER
 */
public class Tugas2a {
    public static void main(String[] args){
        
        int angka;
        String kata;
        
        Scanner input = new Scanner(System.in);
        System.out.println("Masukkan angka: ");
        angka = input.nextInt();
        
        if (angka == 1){
            kata = "satu";
        }else if (angka == 2){
            kata = "dua";
        }else if (angka == 3){
            kata = "tiga";
        }else if (angka == 4){
            kata = "empat";
        }else if (angka == 5){
            kata = "lima";
        }else if (angka == 6){
            kata = "enam";
        }else if (angka == 7){
            kata = "tujuh";
        }else if (angka == 8){
            kata = "delapan";
        }else if (angka == 9){
            kata = "sembilan";
        }else if (angka == 10){
            kata = "sepuluh";
        }
        else{
            kata = "invalid number";
        }
        System.out.println("Angka: " + angka + "=" + kata);
    }
}
