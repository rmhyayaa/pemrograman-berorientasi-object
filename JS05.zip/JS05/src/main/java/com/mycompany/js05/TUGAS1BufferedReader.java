/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//created by 22343028_RamadhaniMaulidiaHilma
package com.mycompany.js05;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 *
 * @author ACER
 */
public class TUGAS1BufferedReader {
    public static void main(String[] args){
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        
        String kata1="", kata2="", kata3="";
        
        try{
            System.out.print("kata pertama : ");
            kata1= dataIn.readLine();
            System.out.print("kata kedua : ");
            kata2= dataIn.readLine();
            System.out.print("kata ketiga : ");
            kata3= dataIn.readLine();
        }
        catch (IOException e){
            System.out.println("gagal membaca keyboard");
        }
        System.out.println(" "+kata1+" "+kata2+" "+kata3);
    }
}
