/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//created by 22343028_RamadhaniMaulidiaHilma
package com.mycompany.js05;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 *
 * @author ACER
 */
public class LATIHAN4 {
    public static void main(String[] args){
        BufferedReader dataIn = new BufferedReader(new InputStreamReader (System.in));
        
        String a, b;
        float angka1, angka2, jumlah;
        System.out.println("Program Penjumlahan Dua buah Bilangan");
        
        try{
            System.out.print ("Masukkan angka pertama : ");
            a = dataIn.readLine();
            
            /*data yang akan di proses aritmatika harus dikonversi dulu dari data
            tipe string ke tipe data angka yang diperlukan. data yang diperoleh 
            dari inputan kelas BufferedReader tipe datanya selalu string*/
            angka1 = Float.parseFloat(a);//konversi dari string ke float
            
            System.out.print ("Masukkan angka kedua : ");
            a = dataIn.readLine();
            angka2 = Float.parseFloat(a);//konversi dari string ke float
            
            jumlah = angka1+angka2;
            System.out.println("jumlah : "+jumlah);
        }
        catch (IOException e){
            System.out.println("Gagal membaca keyboard");
        }
    }
}
