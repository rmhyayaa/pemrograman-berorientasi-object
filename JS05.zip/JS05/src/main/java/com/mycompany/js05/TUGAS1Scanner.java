/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//created by 22343028_RamadhaniMaulidiaHilma

package com.mycompany.js05;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class TUGAS1Scanner {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        
        System.out.print("Masukkan kata pertama : ");
        String kata1 = in.nextLine();
        
        System.out.print("Masukkan kata kedua : ");
        String kata2 = in.nextLine();
        
        System.out.print("Masukkan kata ketiga : ");
        String kata3 = in.nextLine();
        
        System.out.println(" "+kata1+" "+kata2+" "+kata3);
    }
}
