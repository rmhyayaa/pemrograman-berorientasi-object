/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//created by 22343028_RamadhaniMaulidiaHilma
package com.mycompany.js05;

import javax.swing.JOptionPane;

/**
 *
 * @author ACER
 */
public class TUGAS2 {
    public static void main(String[] args){
        String kata1="", kata2="", kata3="";
        
        kata1 = JOptionPane.showInputDialog("Kata Pertama: ");
        kata2 = JOptionPane.showInputDialog("Kata Kedua: ");
        kata3 = JOptionPane.showInputDialog("Kata Ketiga: ");
        
        String msg = " "+kata1+" "+kata2+" "+kata3;
        
        JOptionPane.showMessageDialog(null, msg);
        
        System.out.println(" "+kata1+" "+kata2+" "+kata3);
        
    }
}
