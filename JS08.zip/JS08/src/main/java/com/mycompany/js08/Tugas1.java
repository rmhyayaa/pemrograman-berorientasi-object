/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js08;

/**
 *
 * @author ACER
 */
public class Tugas1 {
    public static void main(String[] args){
        String days[] = {"Moday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        
        for(String day : days){
            System.out.println(day);
        }
    }
}
