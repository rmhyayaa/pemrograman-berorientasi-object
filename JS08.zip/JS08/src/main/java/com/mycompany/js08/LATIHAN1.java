/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js08;

/**
 *
 * @author ACER
 */
public class LATIHAN1 {
    public static void main(String[] args){
        int[] ages = new int[100];
        for (int i = 0; i < 100; i++){
            System.out.print(ages[i]);
        }
    }
}
