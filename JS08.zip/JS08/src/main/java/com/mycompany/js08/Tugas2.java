/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js08;
import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author ACER
 */
public class Tugas2 {
    public static void main(String[] args){
        //Deklarasi array
        int[] numbers = new int[10];
        
        //Membaca input dari user
        for (int i = 0; i<numbers.length; i++){
            numbers[i] = Integer.parseInt(JOptionPane.showInputDialog("Masukkan nomor ke- " +(i + 1) + ": "));
        }
        //Mencari input terbesar
        int largestNumber = numbers[0];
        for (int i = 1; i < numbers.length; i++){
            if(numbers[i] > largestNumber){
                largestNumber = numbers[i];
            }
        }
        //Menampilkan output
        JOptionPane.showMessageDialog(null, "Input terbesar: " + largestNumber);
    }
}
