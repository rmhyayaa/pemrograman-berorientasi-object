/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js07;
//created by 22343028_Ramadhani Maulidia Hilma
/**
 *
 * @author ACER
 */
public class LATIHAN3For {
    public static void main(String[] args){
        int bil;
        for (bil = 0; bil <= 10; bil++)
        System.out.println(bil);
    }
}
