/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js07;
//created by 22343028_RamadhaniMaulidiaHilma
/**
 *
 * @author ACER
 */
public class LATIHAN2For {
    public static void main(String[] args){
        int bilangan;
        for (bilangan = 60; bilangan >=10; bilangan -= 10)
        System.out.println(bilangan);
    }
}
