/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js07;

/**
 *
 * @author ACER
 */
public class Tugas2b {
    public static void main(String[] args){
        int i=100;
        while (i>0){
            System.out.println(i);
            i--;
        }
    }
}
