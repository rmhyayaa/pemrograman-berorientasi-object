/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js04;

/**
 *
 * @author ACER
 */
public class TUGAS2 {
    public static void main(String[] args){
        
        int number1 = 10;
        int number2 = 23;
        int number3 = 5;
        
        int terbesar = number1;
        if (number2 > number1){
            terbesar = number2;
        }
        if (number3 > number2){
            terbesar = number3;
        }
        System.out.println("number 1 = "+number1);
        System.out.println("number 2 = "+number2);
        System.out.println("number 3 = "+number3);
        System.out.println("nilai tertingginya adalah =  "+terbesar);
    }
}
