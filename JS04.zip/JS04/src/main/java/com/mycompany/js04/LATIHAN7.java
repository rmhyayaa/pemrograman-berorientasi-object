/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js04;
//created by 22343028_RamadhaniMaulidiaHilma

/**
 *
 * @author ACER
 */
public class LATIHAN7 {
    public static void main(String[] args){
        int score=0;
        char answer='a';
        
        score = (answer == 'b') ? 10 : 0;
        System.out.println("Score ="+score);
    }
}
