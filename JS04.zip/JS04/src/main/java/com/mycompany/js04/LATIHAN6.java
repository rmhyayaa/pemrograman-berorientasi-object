/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js04;
//created by 22343028_RamadhaniMaulidiaHilma

/**
 *
 * @author ACER
 */
public class LATIHAN6 {
    public static void main (String[] args){
        String status="";
        int grade=50;
        
        //mendapatkan status pelajar
        status = (grade>= 60) ?"passed" : "fail";
        
        //print status
        System.out.println(status);
    }
}
