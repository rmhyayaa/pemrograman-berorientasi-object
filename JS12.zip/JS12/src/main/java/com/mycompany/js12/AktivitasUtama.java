/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js12;

/**
 *
 * @author ACER
 */
class AktivitasUtama{
    public static void main(String[] args){
        AktivitasPagiAnak a1 = new AktivitasPagiAnak();
        
        //panggil method aktivitas pagi anak
        a1.lari();
        a1.berenang();
    }
}
