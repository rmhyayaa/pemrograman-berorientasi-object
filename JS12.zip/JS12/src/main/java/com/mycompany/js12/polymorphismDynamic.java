/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js12;

/**
 *
 * @author ACER
 */
class Bank{
    float sukuBunga(){
        return 0;
    }
}
class BRI extends Bank{
    //overiding suku bungan method
    float sukuBunga(){
        return 5.5f;
    }
} 
class BNI extends Bank{
    //overiding suku bunga method
    float sukuBunga(){
        return 10.6f;
    }
}
class Mandiri extends Bank{
    //overiding suku bunga method
    float sukuBunga(){
        return 9.4f;
    }
}
public class polymorphismDynamic {
    public static void main(String[] args){
        //creating variable of bank class
        Bank B;
        B = new BRI();
        System.out.println("TIngkat suku bunga BRI adalah: " + B.sukuBunga());
        B = new BNI();
        System.out.println("TIngkat suku bunga BNI adalah: " + B.sukuBunga());
        B = new Mandiri();
        System.out.println("TIngkat suku bunga Mandiri adalah: " + B.sukuBunga());
    }
}
