/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.js12;

/**
 *
 * @author ACER
 */
abstract class Orang {
    public String namaAyah = "Randi Proska";
    abstract void makan();
    public void minum(){
        System.out.println("Minum Air Teh dan Kopi");
    }
}

class AnakUmur1Tahun extends Orang{
    public void namaAyahKu(){
        System.out.println("Nama Ayahku adalah "+namaAyah);
    }
    @Override
    public void makan(){
        System.out.println("Anak umur 1 tahun makan ASI");
    }
    
    @Override
    public void minum(){
        System.out.println("Anak umur 1 tahun minum ASI");
    }
}

