//created by 22343028 Ramadhani Maulidia Hilma
package com.mycompany.js02;

/**
 *
 * @author ACER
 */
public class KomentarJava {
    public static void main(String[] args){
        System.out.println("Single line comment above");
        //comment line 1
        System.out.println("Multi line comments below");
        /*Comment line 2
          Comment line 3
          COmment line 4
        */
    }
}
