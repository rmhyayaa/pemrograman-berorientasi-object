//created by 22343028 Ramadhani Maulidia Hilma
package com.mycompany.js02;

/**
 *
 * @author ACER
 */
public class TugasJs2 {
    public static void main(String args[]){
        String satu = "pertama";
        String Satu = "Pertama";
        String SATU = "PERTAMA";
        //perbedaan satu huruf akan memengaruhi yang ditampilkan
        
        System.out.println(satu);
        System.out.println(Satu);
        System.out.println(SATU);
        
    }
}
