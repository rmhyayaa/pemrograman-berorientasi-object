//created by 22343028 Ramadhani Maulidia Hilma
package com.mycompany.js02;

/**
 *
 * @author ACER
 */
public class CaseSensitive {
    public static void main(String args[]){
        String nama = "Petani Kode";
        String Nama = "petanikode";
        String NAMA = "Petanikode.com";
        
        System.out.println(nama);
        System.out.println(Nama);
        System.out.println(NAMA);
    }
            
}
