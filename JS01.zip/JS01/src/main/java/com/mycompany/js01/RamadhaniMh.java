//created by 22343028 Ramadhani Maulidia Hilma
package com.mycompany.js01;

/**
 *
 * @author ACER
 */
public class RamadhaniMh {
    public static void main(String[] args){
        System.out.print("Welcome to Java Programming Ramadhani Maulidia Hilma");
    }
}
