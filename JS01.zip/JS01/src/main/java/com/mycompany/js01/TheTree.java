//created by 22343028 Ramadhani Maulidia Hilma
package com.mycompany.js01;

/**
 *
 * @author ACER
 */
public class TheTree {
    public static void main(String[] args){
        System.out.println("I think I shall never see");
        System.out.println("a poem as lovely as a tree");
        System.out.println("A tree whose hungry mouth is pressed");
        System.out.println("Againts the Earth's sweet flowing breast");
    }
}
