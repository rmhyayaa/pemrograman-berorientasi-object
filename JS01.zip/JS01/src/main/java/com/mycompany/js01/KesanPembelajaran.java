//created by 22343028 Ramadhani Maulidia Hilma
package com.mycompany.js01;

/**
 *
 * @author ACER
 */
public class KesanPembelajaran {
    public static void main(String[] args){
        System.out.println("diawal pembelajaran masih mempelajari pelajaran yang dasar-dasar. ");
        System.out.print("Sehingga belum terasa begitu sulit. Semoga untuk kedepannya tetap dapat memahami "
                + "pembelajaran seperti pada saat awal pembelajaran ini.");
    }
}
