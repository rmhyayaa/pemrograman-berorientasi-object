//created by 22343028 Ramadhani Maulidia Hilma
package com.mycompany.js01;

/**
 *
 * @author ACER
 */
public class Hello {
    public static void main(String[] args){
        System.out.println("Hello Word!");
        System.out.println("Hello Word!");
        System.out.println("Hello Word!");
        
        System.out.print("Hello Word!");
        System.out.print("Hello Word!");
        System.out.print("Hello Word!");
    }
}
